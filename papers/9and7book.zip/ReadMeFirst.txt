If you are installing onto Tradestation, double click the ELD file first to install, then open the worksapce.

